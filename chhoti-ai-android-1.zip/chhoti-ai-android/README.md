# CHHOTI AI (Android, Kotlin)
1. Android Studio (Koala+) me folder open karo, Gradle sync hone do.
2. Samsung M14 USB debugging se connect karo -> Run.
3. App me "Permissions / Floating Button ON" dabao -> Accessibility me CHHOTI AI ON karo.
4. Mic, Contacts, Phone permission pehli baar maangne par allow karo.
5. General AI jawab ke liye AiClient.kt me apna HTTPS backend URL daalo (API key backend par rakho, app me nahi).
Nayi command: CommandRouter.handle() me ek branch jodo.
