package com.chhoti.ai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** General sawaalon ke liye. API key kabhi app me mat daalo: apna secure backend banao jo key server par rakhe.
 *  Backend contract: POST {"message": "..."} -> {"reply": "..."} */
object AiClient {
    const val BASE_URL = "" // e.g. "https://your-backend.example.com/chat"

    fun ask(q: String, cb: (String) -> Unit) {
        if (BASE_URL.isBlank()) { cb("AI backend set nahi hai. AiClient.kt me apna HTTPS backend URL daalo."); return }
        Thread {
            val r = try {
                val c = URL(BASE_URL).openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 10000; c.readTimeout = 20000
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(JSONObject().put("message", q).toString().toByteArray()) }
                JSONObject(c.inputStream.bufferedReader().readText()).optString("reply", "Jawab nahi mila.")
            } catch (e: Exception) { "Network error: ${e.message}" }
            cb(r)
        }.start()
    }
}
