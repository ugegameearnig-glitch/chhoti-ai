package com.chhoti.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

/** Floating button (kisi bhi app ke upar), screen text padhna, power menu kholna. User ki permission (Accessibility) zaroori. */
class AssistantService : AccessibilityService() {
    companion object { var instance: AssistantService? = null }
    private var btn: View? = null
    private var wm: WindowManager? = null

    override fun onServiceConnected() { instance = this; addButton() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean {
        instance = null; btn?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; btn = null
        return super.onUnbind(i)
    }

    fun powerMenu() = performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)

    fun readScreen(): String {
        val out = mutableListOf<String>()
        walk(rootInActiveWindow, out)
        return out.distinct().take(40).joinToString(", ")
    }

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (n == null || out.size > 80) return
        if (!n.isPassword) (n.text ?: n.contentDescription)?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until n.childCount) walk(n.getChild(i), out)
    }

    private fun addButton() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = TextView(this).apply {
            text = "🤖"; textSize = 26f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC06130F.toInt()); setStroke(4, 0xFF2DFF9A.toInt()) }
        }
        val lp = WindowManager.LayoutParams(150, 150, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 400 }
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm?.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) openAssistant()
            }
            true
        }
        wm?.addView(v, lp); btn = v
    }

    private fun openAssistant() {
        val screen = readScreen() // pehle dusre app ki screen padho, phir CHHOTI kholo
        startActivity(Intent(this, MainActivity::class.java).putExtra("listen", true).putExtra("screen", screen)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }
}
