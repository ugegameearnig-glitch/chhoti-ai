package com.chhoti.ai

import android.Manifest.permission.*
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings

/** Voice/text command -> action. Naya command: handle() me ek aur `if` jodo. */
class CommandRouter(private val a: MainActivity) {
    private val cm by lazy { a.getSystemService(Context.CAMERA_SERVICE) as CameraManager }

    fun handle(raw: String) {
        val l = raw.trim().lowercase()
        when {
            l.contains("call") -> {
                val n = Regex("(.+?)\\s+ko\\s+call").find(l)?.groupValues?.get(1)
                    ?: l.replace(Regex("\\b(call|karo|lagao|kar|do|please)\\b"), "").trim()
                if (n.isBlank()) a.reply("Kisko call karun?") else call(n)
            }
            Regex("torch|flash\\s?light|brightness").containsMatchIn(l) -> {
                val pct = Regex("(\\d{1,3})").find(l)?.value?.toInt()?.coerceIn(1, 100)
                torch(!Regex("\\b(off|band|bujha)").containsMatchIn(l), pct)
            }
            Regex("uninstall|delete app").containsMatchIn(l) -> {
                val n = l.replace(Regex("\\b(uninstall|delete|karo|kar|do|ko|app)\\b"), "").trim()
                if (n.isBlank()) a.reply("Kaunsa app uninstall karna hai?") else uninstall(n)
            }
            Regex("power off|phone off|switch off|phone band").containsMatchIn(l) -> powerOff()
            l.contains("screen") && Regex("samjh|dekh|read|batao").containsMatchIn(l) -> screen()
            Regex("\\b(kholo|khol|open)\\b").containsMatchIn(l) -> {
                val n = l.replace(Regex("\\b(kholo|khol|do|open|karo|app)\\b"), "").trim()
                open(n)
            }
            else -> AiClient.ask(raw) { a.reply(it) }
        }
    }

    private fun call(name: String) = a.withPerms(arrayOf(READ_CONTACTS, CALL_PHONE)) {
        val num = a.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.NUMBER), "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
        if (num == null) a.reply("\"$name\" contacts me nahi mila.") else {
            a.reply("$name ko call laga rahi hoon...")
            a.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
        }
    }

    private fun torch(on: Boolean, pct: Int?) {
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return a.reply("Is phone me flashlight nahi mili.")
        try {
            if (on && pct != null && Build.VERSION.SDK_INT >= 33) {
                val max = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                if (max > 1) { cm.turnOnTorchWithStrengthLevel(id, (max * pct / 100).coerceIn(1, max)); return a.reply("Flashlight ON, brightness $pct%") }
            }
            cm.setTorchMode(id, on); a.reply(if (on) "Flashlight ON 🔦" else "Flashlight OFF")
        } catch (e: Exception) { a.reply("Flashlight error: ${e.message}") }
    }

    private fun apps(): List<Pair<String, String>> {
        val pm = a.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
    }
    private fun findApp(n: String) = apps().let { l -> l.firstOrNull { it.first.equals(n, true) } ?: l.firstOrNull { it.first.contains(n, true) } }

    private fun open(n: String) {
        if (n.contains("setting")) { a.startActivity(Intent(Settings.ACTION_SETTINGS)); return a.reply("Settings khol rahi hoon ⚙️") }
        val app = findApp(n) ?: return a.reply("\"$n\" naam ka app nahi mila.")
        val li = a.packageManager.getLaunchIntentForPackage(app.second) ?: return a.reply("${app.first} open nahi ho sakta.")
        a.reply("${app.first} khol rahi hoon..."); a.startActivity(li)
    }

    private fun uninstall(n: String) {
        val app = findApp(n) ?: return a.reply("\"$n\" naam ka app nahi mila.")
        a.reply("${app.first} uninstall karne ke liye confirmation chahiye.")
        a.confirm("${app.first} uninstall karna hai?", "Final delete tum confirm karoge.", "Uninstall") {
            a.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.second}")))
        }
    }

    private fun powerOff() {
        a.reply("Phone ko off karna hai? Android me app se directly power off possible nahi. Main power menu khol sakti hoon.")
        a.confirm("Power menu kholun?", "Wahan se aap power off kar sakte ho.", "Power Menu Open") {
            val s = AssistantService.instance
            if (s == null) a.needAccessibility() else s.powerMenu()
        }
    }

    private fun screen() {
        val t = a.lastScreen.ifBlank { AssistantService.instance?.readScreen() ?: "" }
        when {
            AssistantService.instance == null -> a.needAccessibility()
            t.isBlank() -> a.reply("Screen par padhne layak text nahi mila.")
            else -> a.reply("Screen par ye dikh raha hai: $t")
        }
        a.lastScreen = ""
    }
}
