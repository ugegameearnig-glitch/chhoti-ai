package com.chhoti.ai

import android.Manifest.permission.RECORD_AUDIO
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val green = Color.parseColor("#2DFF9A")
    private val panel = Color.parseColor("#0C241C")
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private var tts: TextToSpeech? = null
    private var sr: SpeechRecognizer? = null
    private lateinit var router: CommandRouter
    private var pendingPerm: (() -> Unit)? = null
    var lastScreen = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int = 16, stroke: Boolean = false) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat(); if (stroke) setStroke(dp(1), green)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        router = CommandRouter(this)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
        buildUi()
        reply("Namaste! Main CHHOTI hoon. Mic dabao ya likho: \"Mummy ko call lagao\", \"flashlight on karo 70\", \"Instagram uninstall karo\".", false)
        handleIntent(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleIntent(i) }
    private fun handleIntent(i: Intent) {
        lastScreen = i.getStringExtra("screen") ?: ""
        if (i.getBooleanExtra("listen", false)) listen()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(24), dp(12), dp(8)) }
        root.addView(TextView(this).apply { text = "CHHOTI AI ●"; textSize = 24f; setTextColor(green); typeface = android.graphics.Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(chat) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply { setTextColor(Color.parseColor("#8FBFA8")); gravity = Gravity.CENTER; text = "Tap karke bolo" }
        val mic = Button(this).apply {
            text = "🎙"; textSize = 30f; background = bg(panel, 50, true); setOnClickListener { listen() }
        }
        root.addView(mic, LinearLayout.LayoutParams(dp(76), dp(76)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        val chips = LinearLayout(this)
        listOf("Call" to "mummy ko call lagao", "Apps" to "settings kholo", "Torch" to "flashlight on karo 70",
            "Screen" to "screen samjhao", "Power" to "phone off karo").forEach { (t, c) ->
            chips.addView(Button(this).apply { text = t; isAllCaps = false; setTextColor(Color.WHITE); background = bg(panel, 20, true); setOnClickListener { send(c) } },
                LinearLayout.LayoutParams(-2, dp(44)).apply { marginEnd = dp(6) })
        }
        root.addView(HorizontalScrollView(this).apply { addView(chips); isHorizontalScrollBarEnabled = false })
        val row = LinearLayout(this)
        input = EditText(this).apply {
            hint = "Likho ya bolo..."; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); background = bg(panel, 14, true)
            setPadding(dp(12), dp(10), dp(12), dp(10)); imeOptions = EditorInfo.IME_ACTION_SEND; setSingleLine()
            setOnEditorActionListener { _, _, _ -> send(text.toString()); true }
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "Send"; setOnClickListener { send(input.text.toString()) } })
        root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(Button(this).apply {
            text = "🔐 Permissions / Floating Button ON"; isAllCaps = false; background = bg(panel, 12)
            setTextColor(green); setOnClickListener { needAccessibility() }
        })
        setContentView(root)
    }

    private fun bubble(t: String, me: Boolean) {
        chat.addView(TextView(this).apply {
            text = t; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(12), dp(8), dp(12), dp(8))
            background = bg(if (me) Color.parseColor("#1769FF") else panel, 14, !me)
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6); gravity = if (me) Gravity.END else Gravity.START })
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    fun send(t: String) {
        val s = t.trim(); if (s.isEmpty()) return
        input.setText(""); bubble(s, true); status.text = "Soch rahi hoon..."
        try { router.handle(s) } catch (e: Exception) { reply("Kuch gadbad ho gayi: ${e.message}") }
    }

    fun reply(t: String, speak: Boolean = true) = runOnUiThread {
        bubble(t, false); status.text = "Tap karke bolo"
        if (speak) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "r")
    }

    fun confirm(title: String, msg: String, yes: String, go: () -> Unit) = runOnUiThread {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setNegativeButton("Cancel", null).setPositiveButton(yes) { _, _ -> go() }.show()
    }

    fun needAccessibility() {
        confirm("Accessibility permission", "Floating button, screen padhna aur power menu ke liye CHHOTI AI ko Accessibility me ON karo.", "Settings kholo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    fun withPerms(p: Array<String>, go: () -> Unit) {
        if (p.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) go()
        else { pendingPerm = go; requestPermissions(p, 2) }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        val ok = r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }
        when {
            c == 1 && ok -> listen()
            c == 2 && ok -> pendingPerm?.invoke()
            else -> reply("Permission nahi mili, isliye ye kaam nahi ho sakta. Phone Settings > Apps > CHHOTI AI me allow karo.")
        }
        pendingPerm = null
    }

    private fun listen() {
        if (checkSelfPermission(RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(RECORD_AUDIO), 1); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return reply("Is phone par voice recognition available nahi hai.")
        tts?.stop(); sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = "Sun rahi hoon..." }
                override fun onResults(r: Bundle?) { r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { send(it) } }
                override fun onError(e: Int) { status.text = "Tap karke bolo"; if (e != SpeechRecognizer.ERROR_NO_MATCH && e != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) reply("Voice error ($e). Internet/mic check karo.", false) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Soch rahi hoon..." }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
        }
    }

    override fun onDestroy() { sr?.destroy(); tts?.shutdown(); super.onDestroy() }
}
